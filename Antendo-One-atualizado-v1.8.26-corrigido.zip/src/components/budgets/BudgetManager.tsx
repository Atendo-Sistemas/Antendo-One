import React, { useEffect, useMemo, useRef, useState } from 'react';
import { budgetApi, clientApi } from '../../services/api';
import { Budget, BudgetExpense, BudgetStatus } from '../../types';
import { generateBudgetPdf } from '../../utils/budgetPdfGenerator';

const brl = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const money = (value: unknown) => Math.round((Number(value) || 0) * 100) / 100;
const previewFinancials = (draft: any) => {
  const expenses = (draft.expenses || []).map((item: BudgetExpense) => ({ ...item, quantity: Number(item.quantity) || 0, unitPrice: money(item.unitPrice), total: money((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0)) }));
  const totalExpenses = money(expenses.reduce((sum: number, item: BudgetExpense) => sum + item.total, 0));
  const routeCost = money((Number(draft.distanceKm) || 0) * (Number(draft.pricePerKm) || 0));
  const tolls = money(draft.tolls);
  const insurance = money(draft.insurance);
  const lodging = money((Number(draft.dailyRate) || 0) * (Number(draft.dailyCount) || 0));
  const assistants = money((Number(draft.assistantCount) || 0) * (Number(draft.assistantDailyRate) || 0) * (Number(draft.dailyCount) || 1));
  const subtotal = money(totalExpenses + routeCost + tolls + insurance + lodging + assistants);
  const taxes = (draft.taxes || []).map((tax: any) => ({ ...tax, percentage: Number(tax.percentage) || 0, fixedValue: money(tax.fixedValue) }));
  const fixedAndScopedTaxes = money(taxes.reduce((sum: number, tax: any) => {
    if (tax.type === 'FIXO') return sum + money(tax.fixedValue);
    if (tax.base === 'DESPESAS') return sum + money(totalExpenses * tax.percentage / 100);
    if (tax.base === 'SUBTOTAL') return sum + money(subtotal * tax.percentage / 100);
    return sum;
  }, 0));
  const freightTaxRate = taxes.reduce((sum: number, tax: any) => sum + (tax.type === 'PERCENTUAL' && tax.base === 'VALOR_FRETE' ? tax.percentage / 100 : 0), 0);
  const calculateProfit = (totalCostValue: number) => draft.profitType === 'FIXO' ? money(draft.profitValue) : money(totalCostValue * (Number(draft.profitValue) || 0) / 100);
  let totalTaxes = fixedAndScopedTaxes;
  let cost = money(subtotal + totalTaxes);
  let profit = calculateProfit(cost);
  let total = money(cost + profit);
  if (freightTaxRate > 0) {
    let previous = total;
    for (let attempt = 0; attempt < 12; attempt += 1) {
      const freightBasedTaxes = money(previous * freightTaxRate);
      totalTaxes = money(fixedAndScopedTaxes + freightBasedTaxes);
      cost = money(subtotal + totalTaxes);
      profit = calculateProfit(cost);
      total = money(cost + profit);
      if (Math.abs(total - previous) < 0.01) break;
      previous = total;
    }
  }
  return { expenseTotal: totalExpenses, routeCost, tolls, insurance, lodging, assistants, taxes: totalTaxes, cost, profit, total };
};
const empty = { clientName: '', date: new Date().toISOString().slice(0, 10), cargoType: '', weightKg: 0, quantity: 1, distanceKm: 0, pricePerKm: 0, priceTableReference: '', tolls: 0, insurance: 0, dailyRate: 0, dailyCount: 0, assistantCount: 0, assistantDailyRate: 0, estimatedMinutes: 0, expenses: [] as BudgetExpense[], taxes: [], profitType: 'PERCENTUAL' as const, profitValue: 20, driverPassed: 0, driverPaid: 0, origin: { address: '', city: '', state: '' }, destination: { address: '', city: '', state: '' } };

type Side = 'origin' | 'destination';
export const BudgetManager: React.FC = () => {
  const [items, setItems] = useState<Budget[]>([]);
  const [draft, setDraft] = useState<any>(empty);
  const [selected, setSelected] = useState<Budget | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [suggestions, setSuggestions] = useState<{ side: Side; items: any[] }>({ side: 'origin', items: [] });
  const [clients, setClients] = useState<any[]>([]);
  const [cnpj, setCnpj] = useState('');
  const [cnpjLoading, setCnpjLoading] = useState(false);
  const [routeLoading, setRouteLoading] = useState(false);
  const addressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const addressCache = useRef(new Map<string, any[]>());
  const refresh = () => budgetApi.list().then(setItems).catch(e => setError(e.message)).finally(() => setLoading(false));
  useEffect(() => { void refresh(); void clientApi.list().then(setClients).catch(e => setError(e.message)); }, []);
  const lookupClient = async () => {
    try {
      setCnpjLoading(true); setError('');
      const result = await clientApi.lookupCnpj(cnpj);
      if (result.existingClient) {
        const existing = result.existingClient;
        setClients(current => current.some(item => item.id === existing.id) ? current : [existing, ...current]);
        setDraft((d: any) => ({ ...d, clientId: existing.id, clientName: existing.legalName }));
        setCnpj('');
        return;
      }
      const data = result.data;
      const e = data.estabelecimento || data;
      const client = { cnpj: result.cnpj, legalName: data.razao_social || data.razaoSocial || '', tradeName: e.nome_fantasia || '', address: e.logradouro || '', number: e.numero || '', neighborhood: e.bairro || '', zipCode: e.cep || '', city: e.cidade?.nome || e.municipio || '', state: e.estado?.sigla || e.uf || '', email: e.email || '', phone: e.telefone1 || '', source: 'CNPJ_WS' as const, cnpjData: data };
      const saved = await clientApi.create(client);
      setClients(current => [saved, ...current]);
      setDraft((d: any) => ({ ...d, clientId: saved.id, clientName: saved.legalName }));
      setCnpj('');
    } catch (e: any) { setError(e.message); } finally { setCnpjLoading(false); }
  };
  const calculateRoute = async () => { const origin = draft.origin?.lat !== undefined && draft.origin?.lng !== undefined ? draft.origin : null; const destination = draft.destination?.lat !== undefined && draft.destination?.lng !== undefined ? draft.destination : null; if (!origin || !destination) return setError('Selecione um endereço de origem e um de destino nas sugestões de endereço.'); try { setRouteLoading(true); setError(''); const route = await budgetApi.directions(origin, destination); setDraft((d: any) => ({ ...d, distanceKm: Number(route.distanceKm.toFixed(2)), estimatedMinutes: Math.round(route.estimatedMinutes), routeGeometry: route.geometry || d.routeGeometry })); } catch (e: any) { setError(e.message); } finally { setRouteLoading(false); } };
  const preview = useMemo(() => previewFinancials(draft), [draft]);
  const save = async () => { if (saving) return; try { setSaving(true); setError(''); const saved = selected ? await budgetApi.update(selected.id, draft) : await budgetApi.create(draft); setSelected(saved); setDraft(saved); await refresh(); } catch (e: any) { setError(e.message); } finally { setSaving(false); } };
  const addExpense = () => setDraft((d: any) => ({ ...d, expenses: [...(d.expenses || []), { id: crypto.randomUUID(), description: 'Combustível', category: 'ABASTECIMENTO', quantity: 1, unit: 'un', unitPrice: 0, total: 0 }] }));
  const status = async (value: BudgetStatus) => { if (!selected) return; try { const result = await budgetApi.status(selected.id, value); setSelected(result); setDraft(result); await refresh(); } catch (e: any) { setError(e.message); } };
  const convert = async () => { if (!selected) return; try { const result = await budgetApi.convert(selected.id); setSelected(result.budget); setDraft(result.budget); await refresh(); } catch (e: any) { setError(e.message); } };
  const downloadPdf = () => { if (!selected) return; try { const { doc, filename } = generateBudgetPdf(selected); const blob = doc.output('blob'); const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.rel = 'noopener'; document.body.appendChild(anchor); anchor.click(); anchor.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000); } catch (e: any) { setError(`Não foi possível gerar o PDF: ${e?.message || 'erro desconhecido'}`); } };
  const printPdf = () => { if (!selected) return; try { const { doc } = generateBudgetPdf(selected); const printWindow = window.open('', '_blank', 'noopener,noreferrer'); if (!printWindow) throw new Error('Permita pop-ups para imprimir o PDF.'); const dataUrl = doc.output('datauristring'); printWindow.document.write(`<iframe src="${dataUrl}" style="border:0;width:100%;height:100vh"></iframe>`); printWindow.document.close(); printWindow.focus(); window.setTimeout(() => printWindow.print(), 700); } catch (e: any) { setError(`Não foi possível imprimir o PDF: ${e?.message || 'erro desconhecido'}`); } };
  const searchAddress = async (side: Side, value: string) => { setDraft((d: any) => ({ ...d, [side]: { ...d[side], address: value } })); if (addressTimer.current) clearTimeout(addressTimer.current); if (value.trim().length < 3) return setSuggestions({ side, items: [] }); const query = value.trim(); const cached = addressCache.current.get(query.toLowerCase()); if (cached) return setSuggestions({ side, items: cached }); addressTimer.current = setTimeout(async () => { try { const result = await budgetApi.geocode(query); addressCache.current.set(query.toLowerCase(), result); setSuggestions({ side, items: result }); } catch { setSuggestions({ side, items: [] }); } }, 350); };
  const chooseAddress = (side: Side, item: any) => { setDraft((d: any) => ({ ...d, [side]: { ...d[side], address: item.address || item.placeName, number: item.number || d[side].number || '', neighborhood: item.neighborhood || d[side].neighborhood || '', zipCode: item.zipCode || d[side].zipCode || '', city: item.city || d[side].city, state: item.state || d[side].state, lat: item.lat, lng: item.lng, mapboxPlaceId: item.id } })); setSuggestions({ side, items: [] }); };
  const addressField = (side: Side, label: string, placeholder: string) => <label className="relative text-sm font-semibold">{label}<input value={draft[side]?.address || ''} onChange={e => void searchAddress(side, e.target.value)} placeholder={placeholder} className="mt-1 w-full rounded-lg border p-2" />{suggestions.side === side && suggestions.items.length > 0 && <div className="absolute z-20 mt-1 w-full rounded-lg border bg-white shadow-xl">{suggestions.items.map(item => <button type="button" key={item.id} onClick={() => chooseAddress(side, item)} className="block w-full border-b p-2 text-left text-xs hover:bg-emerald-50"><strong className="block">{item.placeName}</strong><span className="text-[10px] text-slate-500">{[item.address, item.neighborhood, item.city, item.state, item.zipCode].filter(Boolean).join(' · ')}</span></button>)}</div>}</label>;
  return <section className="space-y-6"><div className="flex items-center justify-between"><div><p className="text-xs font-black uppercase tracking-widest text-emerald-600">Fretes → Orçamentos</p><h1 className="text-2xl font-black">Gerenciamento de Orçamentos</h1></div><button onClick={() => { setSelected(null); setDraft({ ...empty, origin: { ...empty.origin }, destination: { ...empty.destination }, expenses: [] }); }} className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-bold text-white">Novo orçamento</button></div>
    {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
    <div className="grid gap-6 lg:grid-cols-[280px_1fr]"><div className="space-y-2">{loading ? <p>Carregando...</p> : items.map(item => <button key={item.id} onClick={() => { setSelected(item); setDraft(item); }} className={`w-full rounded-xl border p-3 text-left ${selected?.id === item.id ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-white'}`}><div className="font-bold">{item.code}</div><div className="text-xs text-slate-500">{item.clientName || 'Sem cliente'} · {item.status}</div><div className="mt-1 text-sm font-black">{brl(item.financials.totalFreight)}</div></button>)}</div>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="grid gap-3 md:grid-cols-2"><label className="text-sm font-semibold">Cliente cadastrado<select value={draft.clientId || ''} onChange={e => { const c = clients.find(item => item.id === e.target.value); setDraft({ ...draft, clientId: c?.id || undefined, clientName: c?.legalName || draft.clientName }); }} className="mt-1 w-full rounded-lg border p-2"><option value="">Selecione ou informe abaixo</option>{clients.map(client => <option key={client.id} value={client.id}>{client.legalName} · {client.cnpj}</option>)}</select><input value={draft.clientName || ''} onChange={e => setDraft({ ...draft, clientId: undefined, clientName: e.target.value })} placeholder="Nome manual" className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Buscar por CNPJ<div className="mt-1 flex gap-2"><input value={cnpj} onChange={e => setCnpj(e.target.value)} placeholder="00.000.000/0000-00" className="min-w-0 flex-1 rounded-lg border p-2" /><button type="button" onClick={() => void lookupClient()} disabled={cnpjLoading} className="rounded-lg bg-indigo-600 px-3 text-xs font-bold text-white disabled:opacity-50">{cnpjLoading ? 'Consultando…' : 'Consultar e salvar'}</button></div></label><label className="text-sm font-semibold">Data<input type="date" value={draft.date || ''} onChange={e => setDraft({ ...draft, date: e.target.value })} className="mt-1 w-full rounded-lg border p-2" /></label>{addressField('origin', 'Origem', 'Endereço de coleta')}{addressField('destination', 'Destino', 'Endereço de entrega')}<button type="button" onClick={() => void calculateRoute()} disabled={routeLoading} className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm font-bold text-indigo-700 disabled:opacity-50">{routeLoading ? 'Calculando rota…' : 'Calcular rota'}</button><label className="text-sm font-semibold">Tipo de carga<input value={draft.cargoType || ''} onChange={e => setDraft({ ...draft, cargoType: e.target.value })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Distância (km)<input type="number" min="0" value={draft.distanceKm || 0} onChange={e => setDraft({ ...draft, distanceKm: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Valor por km rodado (R$/km)<input type="number" min="0" step="0.01" value={draft.pricePerKm || 0} onChange={e => setDraft({ ...draft, pricePerKm: Number(e.target.value) })} placeholder="Ex.: 4,50" className="mt-1 w-full rounded-lg border p-2" /><span className="mt-1 block text-xs font-normal text-slate-500">Cálculo: distância × valor por km = custo da rota.</span></label></div><div className="mt-4 grid gap-3 md:grid-cols-3"><label className="text-sm font-semibold">Tabela de preços<input value={draft.priceTableReference || ''} onChange={e => setDraft({ ...draft, priceTableReference: e.target.value })} placeholder="Referência manual" className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Pedágios<input type="number" min="0" step="0.01" value={draft.tolls || 0} onChange={e => setDraft({ ...draft, tolls: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Seguro<input type="number" min="0" step="0.01" value={draft.insurance || 0} onChange={e => setDraft({ ...draft, insurance: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Diária (valor)<input type="number" min="0" step="0.01" value={draft.dailyRate || 0} onChange={e => setDraft({ ...draft, dailyRate: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Quantidade de diárias<input type="number" min="0" value={draft.dailyCount || 0} onChange={e => setDraft({ ...draft, dailyCount: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Ajudantes (quantidade)<input type="number" min="0" value={draft.assistantCount || 0} onChange={e => setDraft({ ...draft, assistantCount: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Valor diário por ajudante<input type="number" min="0" step="0.01" value={draft.assistantDailyRate || 0} onChange={e => setDraft({ ...draft, assistantDailyRate: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label></div>
        <div className="mt-6"><div className="flex items-center justify-between"><h2 className="font-black">Despesas da viagem</h2><button onClick={addExpense} className="rounded-lg border px-3 py-1 text-xs font-bold">Adicionar despesa</button></div>{(draft.expenses || []).map((expense: BudgetExpense, index: number) => <div key={expense.id} className="mt-2 grid gap-2 md:grid-cols-[1fr_100px_120px]"> <input value={expense.description} onChange={e => { const expenses = [...draft.expenses]; expenses[index] = { ...expense, description: e.target.value }; setDraft({ ...draft, expenses }); }} className="rounded-lg border p-2" /><input type="number" min="0" value={expense.quantity} onChange={e => { const expenses = [...draft.expenses]; expenses[index] = { ...expense, quantity: Number(e.target.value) }; setDraft({ ...draft, expenses }); }} className="rounded-lg border p-2" /><input type="number" min="0" step="0.01" value={expense.unitPrice} onChange={e => { const expenses = [...draft.expenses]; expenses[index] = { ...expense, unitPrice: Number(e.target.value) }; setDraft({ ...draft, expenses }); }} className="rounded-lg border p-2" /></div>)}</div>
        <div className="mt-6 grid gap-3 md:grid-cols-3"><label className="text-sm font-semibold">Lucro (%)<input type="number" value={draft.profitValue || 0} onChange={e => setDraft({ ...draft, profitValue: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Valor passado motorista<input type="number" value={draft.driverPassed || 0} onChange={e => setDraft({ ...draft, driverPassed: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label><label className="text-sm font-semibold">Valor pago motorista<input type="number" value={draft.driverPaid || 0} onChange={e => setDraft({ ...draft, driverPaid: Number(e.target.value) })} className="mt-1 w-full rounded-lg border p-2" /></label></div>
        <div className="mt-6 grid grid-cols-2 gap-3 rounded-xl bg-slate-900 p-4 text-white md:grid-cols-6"><div><span className="text-xs text-slate-400">Despesas</span><strong className="block">{brl(preview.expenseTotal)}</strong></div><div><span className="text-xs text-slate-400">Rota</span><strong className="block">{brl(preview.routeCost)}</strong></div><div><span className="text-xs text-slate-400">Impostos</span><strong className="block">{brl(preview.taxes)}</strong></div><div><span className="text-xs text-slate-400">Custo</span><strong className="block">{brl(preview.cost)}</strong></div><div><span className="text-xs text-slate-400">Lucro</span><strong className="block">{brl(preview.profit)}</strong></div><div><span className="text-xs text-emerald-300">Total frete</span><strong className="block text-emerald-300">{brl(preview.total)}</strong></div></div>
        <div className="mt-5 flex flex-wrap gap-2"><button onClick={save} disabled={saving} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-50">{saving ? 'Salvando…' : 'Salvar orçamento'}</button>{selected && <><button onClick={downloadPdf} className="rounded-lg border px-3 py-2 text-sm font-bold">Baixar PDF</button><button onClick={printPdf} className="rounded-lg border px-3 py-2 text-sm font-bold">Imprimir PDF</button><button onClick={() => status('EM_ANALISE')} className="rounded-lg border px-3 py-2 text-sm font-bold">Enviar para análise</button><button onClick={() => status('APROVADO')} className="rounded-lg border px-3 py-2 text-sm font-bold">Aprovar</button><button onClick={convert} className="rounded-lg bg-indigo-600 px-3 py-2 text-sm font-bold text-white">Converter em frete</button><button onClick={() => budgetApi.duplicate(selected.id).then(refresh)} className="rounded-lg border px-3 py-2 text-sm font-bold">Duplicar</button></>}</div>
      </div></div></section>;
};
export default BudgetManager;
