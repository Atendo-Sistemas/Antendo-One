import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { CompanyStop, LodgingPartner } from '../../types';
import { AddressAutocomplete } from '../common/AddressAutocomplete';

export const CompanyStopsPanel: React.FC = () => {
  const [stops, setStops] = useState<CompanyStop[]>([]);
  const [partners, setPartners] = useState<LodgingPartner[]>([]);
  const [tab, setTab] = useState<'stops' | 'lodging'>('stops');
  const [form, setForm] = useState({ name: '', address: '', city: '', state: '', phone: '', discount: '', rules: '', type: 'PARADA' });

  const load = async () => { 
    const [s, p] = await Promise.all([api.getCompanyStops(), api.getLodgingPartners()]); 
    setStops(s); 
    setPartners(p); 
  };

  useEffect(() => { void load(); }, []);

  const submit = async (event: React.FormEvent) => { 
    event.preventDefault(); 
    if (tab === 'stops') await api.createCompanyStop(form as any); 
    else await api.createLodgingPartner(form as any); 
    setForm({ name: '', address: '', city: '', state: '', phone: '', discount: '', rules: '', type: 'PARADA' }); 
    await load(); 
  };

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <h1 className="text-xl font-black text-slate-900 dark:text-white">Paradas e hospedagens da empresa</h1>
      <p className="mt-1 text-sm text-slate-500">Cada empresa administra seus próprios pontos. Eles não são compartilhados publicamente com outras empresas.</p>
      
      <div className="mt-5 flex gap-2">
        <button onClick={() => setTab('stops')} className={`rounded-lg px-3 py-2 text-xs font-bold ${tab === 'stops' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>Locais de parada</button>
        <button onClick={() => setTab('lodging')} className={`rounded-lg px-3 py-2 text-xs font-bold ${tab === 'lodging' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>Hospedagens parceiras</button>
      </div>

      <form onSubmit={submit} className="mt-4 grid gap-3 sm:grid-cols-2">
        <input required placeholder="Nome" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm dark:border-slate-800 dark:bg-slate-950" />
        
        <AddressAutocomplete 
          required 
          value={form.address} 
          placeholder="Buscar endereço..."
          onSelect={(data) => setForm(prev => ({ 
            ...prev, 
            address: data.address, 
            city: data.city || prev.city, 
            state: data.state || prev.state 
          }))} 
        />
        
        <input required placeholder="Cidade" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm dark:border-slate-800 dark:bg-slate-950" />
        <input required maxLength={2} placeholder="UF" value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm uppercase dark:border-slate-800 dark:bg-slate-950" />
        <input placeholder="Telefone/WhatsApp" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm dark:border-slate-800 dark:bg-slate-950" />
        
        {tab === 'stops' ? (
          <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm dark:border-slate-800 dark:bg-slate-950">
            <option value="PARADA">Parada</option>
            <option value="POSTO">Posto</option>
            <option value="RESTAURANTE">Restaurante</option>
            <option value="OFICINA">Oficina</option>
            <option value="OUTRO">Outro</option>
          </select>
        ) : (
          <>
            <input placeholder="Desconto" value={form.discount} onChange={e => setForm({ ...form, discount: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm dark:border-slate-800 dark:bg-slate-950" />
            <input placeholder="Regras da parceria" value={form.rules} onChange={e => setForm({ ...form, rules: e.target.value })} className="rounded-lg border border-slate-200 p-2 text-sm dark:border-slate-800 dark:bg-slate-950 sm:col-span-2" />
          </>
        )}
        
        <button className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-bold text-white sm:col-span-2 hover:bg-emerald-700">
          Cadastrar {tab === 'stops' ? 'local' : 'hospedagem'}
        </button>
      </form>

      <div className="mt-6 space-y-2">
        {(tab === 'stops' ? stops : partners).map(item => (
          <div key={item.id} className="rounded-lg border border-slate-200 p-3 text-sm dark:border-slate-700 dark:bg-slate-800/50">
            <strong>{item.name}</strong>
            <span className="ml-2 text-slate-500">{item.city}/{item.state} — {item.address}</span>
            {'discount' in item && item.discount && <span className="ml-2 text-emerald-600">Desconto: {item.discount}</span>}
          </div>
        ))}
      </div>
    </section>
  );
};
