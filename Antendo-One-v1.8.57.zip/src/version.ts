export const APP_VERSION = 'v1.8.57';
export const APP_BUILD_DATE = '27/09/2026';
export const APP_RELEASE_NAME = 'Cadastro de motorista com veículo opcional';
